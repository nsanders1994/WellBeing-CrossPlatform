/*  $("p").on("swipe",function(){
    $("span").text("Swipe detected!");
  });                       
});*/


$(document).on("pagecreate","#pageone",function(){
	$("#test").on("swiperight", function(){
		alert("Swipe Right!");
		document.getElementById("test").innerHTML = "swiped right";
	});
});